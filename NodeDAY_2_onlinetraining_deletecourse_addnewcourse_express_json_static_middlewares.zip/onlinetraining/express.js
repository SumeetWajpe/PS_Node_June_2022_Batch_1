const express = require("express");
const path = require("path");
const app = express(); // app represents your application
var courses = require("./model/course.model");
app.use(express.static("static"));
app.use(express.json());

app.get("/", (req, res) => {
  //   res.send("<h1>Hello Express !</h1>");
  res.sendFile("Courses.html", { root: __dirname });
});

app.get("/courses", (req, res) => {
  res.json(courses);
});

app.post("/newcourse", (req, res) => {
  let newCourse = req.body;
  courses.push(newCourse);
  res.json({ msg: "success" });
});

app.delete("/course/:id", (req, res) => {
  let courseId = +req.params.id; // fetch id from url
  // splice / filter
  courses = courses.filter((course) => course.id !== courseId);
  console.log(courses);
  res.json({ msg: "success" });
});

app.use((req, res) => {
  // res.sendFile("Error.html", { root: __dirname + "/static" });
  res.sendFile("Error.html", { root: path.join(__dirname, "static") });
});
app.listen(4000, () => {
  console.log("Server running @ 4000 !");
});
