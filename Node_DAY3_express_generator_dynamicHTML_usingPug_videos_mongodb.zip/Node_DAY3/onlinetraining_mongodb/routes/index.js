var express = require("express");
var router = express.Router();
var mongodb = require("mongodb");

/* GET home page. */
router.get("/", function (req, res, next) {
  // 1. connect to db [connection string->server->port,ip address]
  // 2. access the db
  // 3. access the collection -> pass data to .pug file

  var MongoClient = mongodb.MongoClient;
  var url = "mongodb://localhost:27017"; // on premise (installed)
  // var url = "mongodb+srv://<username>:<password>@cluster0.afb88.mongodb.net/?retryWrites=true&w=majority" // atlas

  MongoClient.connect(url, { useNewUrlParser: true }, (err, dbconn) => {
    if (err) console.log(err);
    else {
      let coursesCollection = dbconn
        .db("onlinetrainingdb")
        .collection("courses");

      coursesCollection.find({}).toArray((err, result) => {
        if (err) console.log(err);
        else {
          //console.log("Result : " + result.length);
          res.render("index", { title: "Express", courses: result });
        }
      });
    }
  });
});

router.post("/newcourse",(req,res)=>{
  // get data from req.body  -> express.json()
  // MongoClient -> collection -> collection.insertOne({newcourse})

})

router.delete("/course/:id",(req,res)=>{
  // get id from params
  // MongoClient -> collection -> collection.deleteOne({id:id})
})

module.exports = router;
