const express = require("express");
const path = require("path");
const app = express(); // app represents your application
const coursesRouter = require("./routes/courses.routes");
const indexRouter = require("./routes/index.routes");

// Middlewares
app.use(express.static("static"));
app.use(express.json());

// View Engine Set up
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "pug");

//Routes
app.use("/", indexRouter);
app.use("/courses", coursesRouter);

// 404 - Resource not found !
app.use((req, res) => {
  // res.sendFile("Error.html", { root: __dirname + "/static" });
  res.sendFile("Error.html", { root: path.join(__dirname, "static") });
});
app.listen(4000, () => {
  console.log("Server running @ 4000 !");
});
