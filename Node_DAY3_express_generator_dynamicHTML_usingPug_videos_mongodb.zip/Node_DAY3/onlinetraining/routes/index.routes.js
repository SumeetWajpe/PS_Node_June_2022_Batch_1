var express = require("express");
var router = express.Router();

router.get("/", (req, res) => {
  var products = [
    {
      id: 1,
      name: "Mac Book Pro",
      price: 250000,
    },
    {
      id: 2,
      name: "Mac Book Air",
      price: 200000,
    },
    {
      id: 3,
      name: "iPhone",
      price: 50000,
    },
  ];

  res.render("index", { title: "Using Pug !", products });
});

module.exports = router;
