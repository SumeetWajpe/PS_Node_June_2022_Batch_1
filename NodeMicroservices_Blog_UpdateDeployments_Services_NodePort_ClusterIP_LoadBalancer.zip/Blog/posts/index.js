const express = require("express");
const axios = require("axios").default;
const app = express();
const { randomBytes } = require("crypto");

const cors = require("cors");
app.use(express.json()); // parse request body in JSON
app.use(cors());

const posts = {}; // db

app.get("/posts", (req, res) => {
  res.send(posts);
});

app.post("/posts/create", async (req, res) => {
  const id = randomBytes(4).toString("hex");
  const { title } = req.body;

  // storing post
  posts[id] = {
    id,
    title,
  };

  // raising an event
  await axios
    .post("http://event-bus-srv:4005/events", {
      type: "PostCreated",
      data: {
        id,
        title,
      },
    })
    .catch((err) => console.log(err));

  res.status(201).send(posts[id]);
});

app.post("/events", (req, res) => {
  console.log("Received Event : ", req.body.type);
  res.send({});
});

app.listen(4000, () => {
  console.log("This is version 4 !");
  console.log("Post Service running @ 4000 !");
});
