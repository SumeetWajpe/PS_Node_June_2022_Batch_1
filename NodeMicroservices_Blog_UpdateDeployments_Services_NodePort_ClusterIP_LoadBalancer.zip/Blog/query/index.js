const express = require("express");
const app = express();
const cors = require("cors");
const axios = require("axios").default;

app.use(express.json()); // parse request body in JSON
app.use(cors());

const posts = {}; // db

app.get("/posts", (req, res) => {
  res.send(posts);
});

app.post("/events", (req, res) => {
  // assembling posts and their respective comments
  //   console.log("Received Event : ", req.body.type);

  const { type, data } = req.body;

  if (type === "PostCreated") {
    const { id, title } = data;
    posts[id] = { id, title, comments: [] };
  }

  if (type === "CommentCreated") {
    const { id, content, postId } = data;
    const post = posts[postId];
    post.comments.push({ id, content });
  }
  res.send({});
});
app.listen(4002, () => {
  console.log("Query Service running @ 4002 !");
});
