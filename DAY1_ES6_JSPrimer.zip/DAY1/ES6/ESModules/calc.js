import Addition, { Product } from "./mathmodule.js";

console.log("The addition is : " + Addition(40, 50));
console.log("The product is : " + Product(40, 50));
