const http = require("http");
const socket = require("socket.io");
const fs = require("fs");

const hostname = "127.0.0.1";
const port = 3000;

const server = http.createServer((req, res) => {
  fs.readFile("clientpeer.html", (err, dataFromFile) => {
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/html");
    res.end(dataFromFile);
  });
});

var io = socket(server); // socket regstrd on server
io.sockets.on("connection", function (skt) {
  setInterval(() => {
    var dataToBeSent = new Date();
    skt.emit("custom_msg_from_server_peer", dataToBeSent);
  }, 2000);

  skt.on("custom_msg_from_client_peer", (dataFromClientPeer) => {
    console.log(`Data from client peer : ${dataFromClientPeer}`);
  });
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});
