console.log("Script loaded !");
