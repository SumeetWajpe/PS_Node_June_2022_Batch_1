var fs = require("fs");

// non-blocking way

// fs.readFile("Input.txt", (err, dataFromFile) => {
//   if (err) console.log(err);
//   else console.log(dataFromFile.toString());
// });

// blocking code
let dataFromFile = fs.readFileSync("Input.txt");
console.log(dataFromFile.toString());

console.log("Program Ended..");
