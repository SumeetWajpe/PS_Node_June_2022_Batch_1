import Addition, { Product as Multiplication } from "./Math.js";

console.log("The addition is : " + Addition(30, 50));
console.log("The product is : " + Multiplication(30, 50));
