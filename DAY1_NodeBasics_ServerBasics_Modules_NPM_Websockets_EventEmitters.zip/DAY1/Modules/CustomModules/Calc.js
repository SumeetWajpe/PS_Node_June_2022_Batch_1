var MathModule = require("./Math");

console.log(MathModule.Add(20, 30));
console.log(MathModule.Multiplication(20, 30));
