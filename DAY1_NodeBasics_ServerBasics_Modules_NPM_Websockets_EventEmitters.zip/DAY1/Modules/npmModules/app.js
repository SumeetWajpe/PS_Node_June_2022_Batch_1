const axios = require("axios").default;

axios
  .get("https://jsonplaceholder.typicode.com/pos")
  .then(function (response) {
    // handle success
    console.log(response);
  })
  .catch(function (error) {
    // handle error
    console.log(error);
  });
