const EventEmitter = require("events").EventEmitter;

// publisher
function ItemIterator(theMaxCount) {
  var e = new EventEmitter();
  process.nextTick(() => {
    e.emit("started");
    let count = 0;
    let t = setInterval(() => {
      e.emit("item", ++count);
      if (count === theMaxCount) {
        e.emit("done", count);
        clearInterval(t);
      }

      if (count === 8) {
        e.emit("error", count);
        clearInterval(t);
      }
    }, 500);
  });
  return e;
}

// subscriber

var evt = ItemIterator(10);

evt.on("started", () => {
  console.log("The iteration begins..");
});

evt.on("item", (count) => {
  console.log("Emitted : " + count);
});

evt.on("error", (count) => {
    console.log("Encountered error at count : " + count);
  });

evt.on("done", (finalCount) => {
  console.log("The iteration Ended with final count : " + finalCount);
});
