const fs = require("fs");

let readableStream = fs.createReadStream("Input.txt");
let writableStream = fs.createWriteStream("Output.txt");

let allData = "";
readableStream.on("data", function (chunk) {
  //   console.log(chunk.toString());

  console.log("\n\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>> CHUNK >>>>>>>>>>>>>>>>>");
  //allData += chunk;
  writableStream.write(chunk);
});

readableStream.on("end", function () {
  writableStream.end();
});

// readableStream.pipe(writableStream);
